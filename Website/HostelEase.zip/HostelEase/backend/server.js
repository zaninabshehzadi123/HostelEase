/* eslint-disable prettier/prettier */
const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const cors = require('cors'); // Add this line

const app = express();
const PORT = process.env.PORT || 4000;

app.use(bodyParser.json());
app.use(cors()); // Add this line to enable CORS

const pool = new Pool({
  user: 'postgres',
  host: '54.211.145.126',
  database: 'HostelEase',
  password: 'postgres',
  port: 5432,
});

// Check database connection
pool.connect((err, client, release) => {
  if (err) {
    return console.error('Error acquiring client', err.stack);
  }
  console.log('Connected to PostgreSQL database');
  release();
});


// Add a new endpoint to get data from the database
app.get('/api/students', async (req, res) => {
  try {
    // Retrieve all students from the database
    const result = await pool.query('SELECT * FROM students');
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error retrieving students:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});
app.post('/api/students', async (req, res) => {
  try {
    const { rollNo, studName, cgpa, phoneNumber, city } = req.body;

    // Validate the incoming data (similar to your frontend validation)
    // ...

    // Insert the new student record into the database
    const result = await pool.query('INSERT INTO students (roll_no, name, cgpa, phone_number, city) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [rollNo, studName, cgpa, phoneNumber, city]);

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error adding student:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


app.delete('/api/students/:roll_no', async (req, res) => {
  try {
    const rollNoToDelete = req.params.roll_no;

    // Perform the deletion in the database based on the provided roll_no
    const result = await pool.query('DELETE FROM students WHERE roll_no = $1 RETURNING *', [
      rollNoToDelete,
    ]);

    if (result.rows.length === 0) {
      // No record found with the specified roll_no
      res.status(404).json({ error: 'Record not found or already deleted' });
    } else {
      // Record successfully deleted
      res.json({ message: 'Record deleted successfully', deletedRecord: result.rows[0] });
    }
  } catch (error) {
    console.error('Error deleting student record:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Add this route for authentication
app.post('/api/adminLogin', async (req, res) => {
  console.log("Server Side")
  try {
    const { username, password } = req.body;
    console.log(username)
    // Check the credentials against the adminLogin table in the database
    const result = await pool.query('SELECT * FROM adminLogin WHERE username = $1 AND password = $2', [
      username,
      password,
    ]);

    if (result.rows.length > 0) {
      // Authentication successful
      res.json({ message: 'Login successful' });
    } else {
      // Authentication failed
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch (error) {
    console.error('Error during authentication:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


// Define the API endpoint to fetch data
app.get('/api/roomAllocationApplications', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM roomAllocationApplications');
    const data = result.rows;
    res.json(data);
  } catch (error) {
    console.error('Error fetching data:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


// Add a new endpoint to delete a room allocation application
app.delete('/api/roomAllocationApplications/:roll_number', async (req, res) => {
  try {
    const rollNumberToDelete = req.params.roll_number;
    const { roomcategory, roomnumber } = req.body;

    // Perform the deletion in the database based on the provided roll_number, roomcategory, and roomnumber
    const result = await pool.query(
      'DELETE FROM roomAllocationApplications WHERE roll_number = $1 AND roomcategory = $2 AND roomnumber = $3 RETURNING *',
      [rollNumberToDelete, roomcategory, roomnumber]
    );

    if (result.rows.length === 0) {
      // No record found with the specified criteria
      res.status(404).json({ error: 'Record not found or already deleted' });
    } else {
      // Record successfully deleted
      res.json({ message: 'Record deleted successfully', deletedRecord: result.rows[0] });
    }
  } catch (error) {
    console.error('Error deleting room allocation record:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


// app.get('/api/searchRoomAllocation', async (req, res) => {
//   console.log('Searching')
//   try {
//     const { roomcategory, roomnumber } = req.query;
//     //console.log(roomcategory)
//     //console.log(roomnumber)
//     // Determine the table based on room category
//     let tableName;
//     if (roomcategory === 'shared') {
//       tableName = 'sharedrooms';
//     } else if (roomcategory === 'double') {
//       tableName = 'twoseaterroom';
//     } else if (roomcategory === 'single') {
//       tableName = 'singleseater';
//     } else {
//       return res.status(400).json({ error: 'Invalid room category' });
//     }
//     // Fetch the row from the respective table
//     const result = await pool.query(`SELECT * FROM ${tableName} WHERE id = $1`, [roomnumber]);

//     if (result.rows.length === 0) {
//       return res.status(404).json({ error: 'No record found' });
//     }
//     console.log(result)
//     // Convert the first "Applied" value into roll number
//     let rollNumber;
//     if (roomcategory === 'Shared') {
//       rollNumber = result.rows[0].member1;
//     } else if (roomcategory === 'Double') {
//       rollNumber = result.rows[0].member1;
//     } else if (roomcategory === 'Single') {
//       rollNumber = result.rows[0].member1;
//     }

//     res.json({ rollNumber });
//   } catch (error) {
//     console.error('Error searching room allocation:', error.message);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });


app.get('/api/searchRoomAllocation', async (req, res) => {
  console.log('Searching');
  try {
    const { roomcategory, roomnumber, rollnumber } = req.query;
    let tableName;

    // Determine the table based on room category
    if (roomcategory.toLowerCase() === 'shared') {
      tableName = 'sharedrooms';
    } else if (roomcategory.toLowerCase() === 'double') {
      tableName = 'twoseaterroom';
    } else if (roomcategory.toLowerCase() === 'single') {
      tableName = 'singleseater';
    } else {
      return res.status(400).json({ error: 'Invalid room category' });
    }

    // Fetch the row from the respective table
    const result = await pool.query(`SELECT * FROM ${tableName} WHERE id = $1`, [roomnumber]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'No record found' });
    }

   // Convert the first "Applied" value into roll number
let rollNumber = rollnumber;
const members = result.rows[0];

for (const memberKey in members) {
  if (members[memberKey] === 'Applied' && memberKey.startsWith('member')) {
    console.log('Came to change roll number');

    // Ensure rollNumber is a string
    rollNumber = String(rollNumber); // Explicitly convert to string
    console.log(rollNumber)
   // Update the database with the correct roll number
   const updateResult = await pool.query(
    `UPDATE ${tableName} SET ${memberKey} = $1 WHERE id = $2`, // Remove RETURNING *
    [rollNumber, roomnumber]
  );
  console.log(memberKey)
  console.log('Database updated:', updateResult);

  // Logging the updated row requires a separate query:
  const updatedRow = await pool.query(
    `SELECT * FROM ${tableName} WHERE id = $1`,
    [roomnumber]
  );
  console.log('Updated Row:', updatedRow.rows[0])
// Insert the rollNumber into the BookedStudents table
const insertResult = await pool.query(
  'INSERT INTO BookedStudents (rollNumber) VALUES ($1)',
  [rollNumber]
);
console.log('RollNumber inserted into BookedStudents table:', insertResult);

    break; // Stop as soon as the first "Applied" value is found
  }
}

    res.json({ rollNumber });
  } catch (error) {
    console.error('Error searching room allocation:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});



app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
