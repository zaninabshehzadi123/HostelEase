export const blue = '#87ceeb';
export const darkGreen = '#006A42';